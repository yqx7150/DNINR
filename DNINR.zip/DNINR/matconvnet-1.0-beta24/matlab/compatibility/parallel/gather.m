function x=gather(x)
% GATHER  Compatibility stub for the GATHER() function
%   GATHER() is a function in the Parallel MATLAB toolbox. MATCONVNET
%   can work without it.
