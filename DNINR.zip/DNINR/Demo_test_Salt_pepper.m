clear; clc;
addpath('utilities');
addpath('./matconvnet-1.0-beta24/matlab/');
run ('./matconvnet-1.0-beta24/matlab/vl_setupnn.m');

folderTest='./Set12/';
folderModel = 'model_70/';
noiseSigma  = 70;  %%% image noise level
showResult  = 0;
useGPU      = 1;
pauseTime   = 1;
isSaveResult = 0;

%%% PSNR and SSIM
PSNRs = zeros(40,10);
SSIMs = zeros(40,10);


for ii = 180000:5000:180000
    load(fullfile(folderModel, ['SPN__3_70_' num2str(ii) '.mat']));
    ext         =  {'*.tif','*.png','*.bmp'};
    filePaths   =  [];
    
    for i = 1 : length(ext)
        filePaths = cat(1,filePaths, dir(fullfile(folderTest,ext{i})));
    end

    for i = 1:length(filePaths)
        label = imread(fullfile(folderTest,filePaths(i).name));
        [H,W,Z]=size(label);
        [~,nameCur,extCur] = fileparts(filePaths(i).name);
        disp([num2str(i),'    ',filePaths(i).name,'    ',num2str(noiseSigma)]);
        if(size(label,3)>1)
            label = rgb2ycbcr(label);
            label=label(:, :, 1);
        end
        
        label = im2double(label);

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        M = label;
        xx = rand(size(label));
        p3 = 0.7;
        M(xx < p3/2) = 0; % Minimum value
        M(xx >= p3/2 & xx < p3) = 1; % Maximum (saturated) value
        input = M;
     
        tic;

        output=NIDCN_SP(input,model);
        
        timeCur=toc;
        PSNRCur = 20*log10(1/sqrt(mean((label(:)-output(:)).^2)));

        SSIMCur = ssim_index10(label,output);
        if showResult
            imshow(cat(2,im2uint8(label),im2uint8(input),im2uint8(output)));
            title([filePaths(i).name,'    ',num2str(PSNRCur,'%2.2f'),'dB','    ',num2str(SSIMCur,'%2.4f')])
            drawnow;
            pause(pauseTime)
        else
            disp([filePaths(i).name,'    ',num2str(PSNRCur,'%2.2f'),'dB','    ',num2str(SSIMCur,'%2.4f'),'     ',num2str(timeCur,'%2.2f')]);
            %             disp([filePaths(i).name,'    ',num2str(PSNRCur,'%2.2f'),'dB','  ',num2str(SSIMCur,'%2.4f'),'    ',num2str(timeCur,'%2.2f')]);
        end

        PSNRs(ii/5000,i)= PSNRCur;
        SSIMs(ii/5000,i) = SSIMCur;
        Times(ii/5000,i) = timeCur;
        
        if isSaveResult
            
            imwrite(im2uint8(label),fullfile(savepath,[nameCur '_original.bmp']));
            imwrite(im2uint8(input),fullfile(savepath,[nameCur '_noisy_N' num2str(noiseSigma) '.bmp']));
            imwrite(im2uint8(output),fullfile(savepath,[nameCur '_recover_SP_N' num2str(noiseSigma) '.bmp']));

        end
    end
    

end

